"""
Discord Quran Bot - Professional 24/7 Quran streaming bot.
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__description__ = "A professional Discord bot for 24/7 Quran recitation streaming" 