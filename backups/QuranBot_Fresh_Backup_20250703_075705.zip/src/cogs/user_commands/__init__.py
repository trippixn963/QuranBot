from .control_panel import setup
 
__all__ = ['setup'] 