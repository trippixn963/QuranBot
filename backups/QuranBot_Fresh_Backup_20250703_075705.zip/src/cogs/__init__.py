# Cogs package for QuranBot admin commands
