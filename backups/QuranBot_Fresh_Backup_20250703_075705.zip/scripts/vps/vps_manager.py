#!/usr/bin/env python3
"""
VPS Manager for QuranBot
Manages the QuranBot deployment on the VPS with specific configuration.
"""

import os
import sys
import subprocess
import json
import time
import argparse
from pathlib import Path
from typing import Dict, List, Optional

# VPS Configuration
VPS_CONFIG = {
    "ip": "159.89.90.90",
    "user": "root",
    "ssh_key": "quranbot_key",
    "ssh_key_path": "C:/Users/hanna/Documents/QuranBot/quranbot_key",
    "bot_directory": "/home/QuranAudioBot",
    "local_project_path": "C:/Users/hanna/Documents/QuranBot",
    "repo_url": "https://github.com/yourusername/QuranBot.git",  # Update with your actual repo URL
    "venv_name": "venv",
    "log_file": "bot.log",
    "service_name": "quranbot"
}

class VPSManager:
    def __init__(self):
        self.config = VPS_CONFIG
        self.ssh_base_cmd = f"ssh -i {self.config['ssh_key_path']} {self.config['user']}@{self.config['ip']}"
        
    def run_ssh_command(self, command: str, capture_output: bool = True) -> subprocess.CompletedProcess:
        """Run a command on the VPS via SSH."""
        full_command = f"{self.ssh_base_cmd} '{command}'"
        print(f"Running: {full_command}")
        
        try:
            if capture_output:
                result = subprocess.run(full_command, shell=True, capture_output=True, text=True)
            else:
                result = subprocess.run(full_command, shell=True)
            return result
        except Exception as e:
            print(f"Error running SSH command: {e}")
            return subprocess.CompletedProcess(full_command, 1, "", str(e))

    def check_connection(self) -> bool:
        """Test SSH connection to VPS."""
        print("🔍 Testing SSH connection...")
        result = self.run_ssh_command("echo 'Connection successful'")
        if result.returncode == 0:
            print("✅ SSH connection successful!")
            return True
        else:
            print("❌ SSH connection failed!")
            print(f"Error: {result.stderr}")
            return False

    def get_bot_status(self) -> Dict:
        """Get current bot status."""
        print("📊 Getting bot status...")
        
        # Check if bot process is running
        result = self.run_ssh_command(f"ps aux | grep 'python run.py' | grep -v grep")
        is_running = result.returncode == 0 and result.stdout.strip()
        
        # Get recent logs
        log_result = self.run_ssh_command(f"tail -10 {self.config['bot_directory']}/{self.config['log_file']}")
        recent_logs = log_result.stdout if log_result.returncode == 0 else "No logs available"
        
        # Get disk usage
        disk_result = self.run_ssh_command(f"df -h {self.config['bot_directory']}")
        disk_usage = disk_result.stdout if disk_result.returncode == 0 else "Unknown"
        
        # Get memory usage
        mem_result = self.run_ssh_command("free -h")
        memory_usage = mem_result.stdout if mem_result.returncode == 0 else "Unknown"
        
        return {
            "is_running": bool(is_running),
            "recent_logs": recent_logs,
            "disk_usage": disk_usage,
            "memory_usage": memory_usage
        }

    def start_bot(self) -> bool:
        """Start the QuranBot on VPS."""
        print("🚀 Starting QuranBot...")
        
        # Kill any existing processes
        self.run_ssh_command(f"pkill -f 'python run.py'", capture_output=False)
        time.sleep(2)
        
        # Start the bot
        start_cmd = f"cd {self.config['bot_directory']} && source {self.config['venv_name']}/bin/activate && nohup python run.py > {self.config['log_file']} 2>&1 &"
        result = self.run_ssh_command(start_cmd, capture_output=False)
        
        if result.returncode == 0:
            print("✅ Bot started successfully!")
            time.sleep(3)
            # Verify it's running
            status = self.get_bot_status()
            if status["is_running"]:
                print("✅ Bot is confirmed running!")
                return True
            else:
                print("⚠️ Bot may not have started properly. Check logs.")
                return False
        else:
            print("❌ Failed to start bot!")
            return False

    def stop_bot(self) -> bool:
        """Stop the QuranBot on VPS."""
        print("🛑 Stopping QuranBot...")
        result = self.run_ssh_command(f"pkill -f 'python run.py'", capture_output=False)
        
        if result.returncode == 0:
            print("✅ Bot stopped successfully!")
            return True
        else:
            print("⚠️ Bot may not have been running or failed to stop.")
            return False

    def restart_bot(self) -> bool:
        """Restart the QuranBot on VPS."""
        print("🔄 Restarting QuranBot...")
        if self.stop_bot():
            time.sleep(2)
            return self.start_bot()
        return False

    def deploy_bot(self) -> bool:
        """Deploy the bot to VPS (pull latest changes and restart)."""
        print("📦 Deploying QuranBot...")
        
        # Pull latest changes
        pull_cmd = f"cd {self.config['bot_directory']} && git pull origin main"
        result = self.run_ssh_command(pull_cmd)
        
        if result.returncode != 0:
            print("❌ Failed to pull latest changes!")
            print(f"Error: {result.stderr}")
            return False
        
        print("✅ Code updated successfully!")
        
        # Install/update dependencies
        install_cmd = f"cd {self.config['bot_directory']} && source {self.config['venv_name']}/bin/activate && pip install -r requirements.txt"
        result = self.run_ssh_command(install_cmd)
        
        if result.returncode != 0:
            print("⚠️ Warning: Some dependencies may not have installed properly.")
        
        # Restart the bot
        return self.restart_bot()

    def view_logs(self, lines: int = 50) -> None:
        """View bot logs."""
        print(f"📋 Showing last {lines} lines of bot logs...")
        result = self.run_ssh_command(f"tail -{lines} {self.config['bot_directory']}/{self.config['log_file']}")
        
        if result.returncode == 0:
            print("\n" + "="*80)
            print("BOT LOGS:")
            print("="*80)
            print(result.stdout)
            print("="*80)
        else:
            print("❌ Failed to retrieve logs!")

    def upload_audio_files(self, local_audio_path: str) -> bool:
        """Upload audio files to VPS."""
        print("📤 Uploading audio files...")
        
        if not os.path.exists(local_audio_path):
            print(f"❌ Local audio path not found: {local_audio_path}")
            return False
        
        # Create remote audio directory
        self.run_ssh_command(f"mkdir -p {self.config['bot_directory']}/audio")
        
        # Upload using scp
        scp_cmd = f"scp -i {self.config['ssh_key_path']} -r {local_audio_path}/* {self.config['user']}@{self.config['ip']}:{self.config['bot_directory']}/audio/"
        
        print(f"Running: {scp_cmd}")
        result = subprocess.run(scp_cmd, shell=True)
        
        if result.returncode == 0:
            print("✅ Audio files uploaded successfully!")
            return True
        else:
            print("❌ Failed to upload audio files!")
            return False

    def backup_bot(self) -> bool:
        """Create a backup of the bot."""
        print("💾 Creating backup...")
        
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        backup_cmd = f"cd {self.config['bot_directory']} && tar -czf backup_{timestamp}.tar.gz --exclude=venv --exclude=*.log --exclude=__pycache__ ."
        result = self.run_ssh_command(backup_cmd)
        
        if result.returncode == 0:
            print(f"✅ Backup created: backup_{timestamp}.tar.gz")
            return True
        else:
            print("❌ Failed to create backup!")
            return False

    def setup_environment(self) -> bool:
        """Initial setup of the bot environment on VPS."""
        print("🔧 Setting up bot environment...")
        
        # Clone repository if it doesn't exist
        clone_cmd = f"if [ ! -d '{self.config['bot_directory']}' ]; then git clone {self.config['repo_url']} {self.config['bot_directory']}; fi"
        result = self.run_ssh_command(clone_cmd)
        
        if result.returncode != 0:
            print("❌ Failed to clone repository!")
            return False
        
        # Create virtual environment
        venv_cmd = f"cd {self.config['bot_directory']} && python3 -m venv {self.config['venv_name']}"
        result = self.run_ssh_command(venv_cmd)
        
        if result.returncode != 0:
            print("❌ Failed to create virtual environment!")
            return False
        
        # Install dependencies
        install_cmd = f"cd {self.config['bot_directory']} && source {self.config['venv_name']}/bin/activate && pip install -r requirements.txt"
        result = self.run_ssh_command(install_cmd)
        
        if result.returncode != 0:
            print("⚠️ Warning: Some dependencies may not have installed properly.")
        
        # Create necessary directories
        mkdir_cmd = f"cd {self.config['bot_directory']} && mkdir -p logs audio"
        self.run_ssh_command(mkdir_cmd)
        
        print("✅ Environment setup completed!")
        return True

    def interactive_menu(self):
        """Interactive menu for VPS management."""
        while True:
            print("\n" + "="*60)
            print("🤖 QuranBot VPS Manager")
            print("="*60)
            print("1.  Check Connection")
            print("2.  Get Bot Status")
            print("3.  Start Bot")
            print("4.  Stop Bot")
            print("5.  Restart Bot")
            print("6.  Deploy Bot (Pull & Restart)")
            print("7.  View Logs")
            print("8.  Upload Audio Files")
            print("9.  Create Backup")
            print("10. Setup Environment")
            print("11. Exit")
            print("="*60)
            
            choice = input("Enter your choice (1-11): ").strip()
            
            if choice == "1":
                self.check_connection()
            elif choice == "2":
                status = self.get_bot_status()
                print(f"\nBot Status: {'🟢 Running' if status['is_running'] else '🔴 Stopped'}")
                print(f"\nRecent Logs:\n{status['recent_logs']}")
            elif choice == "3":
                self.start_bot()
            elif choice == "4":
                self.stop_bot()
            elif choice == "5":
                self.restart_bot()
            elif choice == "6":
                self.deploy_bot()
            elif choice == "7":
                lines = input("Number of log lines to show (default 50): ").strip()
                lines = int(lines) if lines.isdigit() else 50
                self.view_logs(lines)
            elif choice == "8":
                audio_path = input("Enter local audio files path: ").strip()
                if audio_path:
                    self.upload_audio_files(audio_path)
                else:
                    print("❌ No path provided!")
            elif choice == "9":
                self.backup_bot()
            elif choice == "10":
                self.setup_environment()
            elif choice == "11":
                print("👋 Goodbye!")
                break
            else:
                print("❌ Invalid choice!")
            
            input("\nPress Enter to continue...")

def main():
    parser = argparse.ArgumentParser(description="QuranBot VPS Manager")
    parser.add_argument("action", nargs="?", choices=[
        "status", "start", "stop", "restart", "deploy", "logs", 
        "upload", "backup", "setup", "check", "menu"
    ], help="Action to perform")
    parser.add_argument("--lines", "-l", type=int, default=50, help="Number of log lines to show")
    parser.add_argument("--audio-path", "-a", help="Path to audio files for upload")
    
    args = parser.parse_args()
    
    manager = VPSManager()
    
    if args.action == "status":
        status = manager.get_bot_status()
        print(f"Bot Status: {'🟢 Running' if status['is_running'] else '🔴 Stopped'}")
        print(f"Recent Logs:\n{status['recent_logs']}")
    elif args.action == "start":
        manager.start_bot()
    elif args.action == "stop":
        manager.stop_bot()
    elif args.action == "restart":
        manager.restart_bot()
    elif args.action == "deploy":
        manager.deploy_bot()
    elif args.action == "logs":
        manager.view_logs(args.lines)
    elif args.action == "upload":
        if args.audio_path:
            manager.upload_audio_files(args.audio_path)
        else:
            print("❌ Please provide audio path with --audio-path")
    elif args.action == "backup":
        manager.backup_bot()
    elif args.action == "setup":
        manager.setup_environment()
    elif args.action == "check":
        manager.check_connection()
    elif args.action == "menu" or not args.action:
        manager.interactive_menu()
    else:
        parser.print_help()

if __name__ == "__main__":
    main() 